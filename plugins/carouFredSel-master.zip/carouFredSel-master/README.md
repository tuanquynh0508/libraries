carouFredSel
============

A circular, responsive carousel plugin built using the jQuery. See http://caroufredsel.dev7studios.com

Docs: http://docs.dev7studios.com/jquery-plugins/caroufredsel
